#ifndef _VERSION_H_
#define _VERSION_H_
static const char *XDO_VERSION = "3.20160805.1";
#endif /* ifndef _VERSION_H */
